import crypto from "crypto";

/**
 * Generate a random 6-digit OTP
 */
export const generateOTP = (): string => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

/**
 * Hash an OTP using SHA-256 before storing in DB
 */
export const hashOTP = (otp: string): string => {
  return crypto.createHash("sha256").update(otp).digest("hex");
};

/**
 * Compare a plain OTP with a stored hash
 */
export const verifyOTPHash = (plainOTP: string, hashedOTP: string): boolean => {
  const hash = hashOTP(plainOTP);
  return hash === hashedOTP;
};

/**
 * OTP expiry: 5 minutes from now
 */
export const getOTPExpiry = (): Date => {
  return new Date(Date.now() + 5 * 60 * 1000);
};

/**
 * Dummy SMS service — logs OTP to console in development
 * Replace this with Twilio / MSG91 / Fast2SMS in production
 */
export const sendOTP = async (mobile: string, otp: string): Promise<void> => {
  if (process.env.NODE_ENV === "production") {
    // TODO: integrate real SMS provider here
    // e.g. await twilioClient.messages.create({ ... })
    console.log(`[SMS] Sent OTP ${otp} to ${mobile}`);
  } else {
    // DEV: just log it
    console.log(`\n📱 ==========================================`);
    console.log(`   OTP for ${mobile}: ${otp}`);
    console.log(`   Expires in 5 minutes`);
    console.log(`==========================================\n`);
  }
};
